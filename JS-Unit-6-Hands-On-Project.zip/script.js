// script.js

document.getElementById('paymentForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting

    // Clear previous errors
    document.getElementById('cardNumberError').textContent = '';
    document.getElementById('expiryDateError').textContent = '';
    document.getElementById('cvvError').textContent = '';

    // Get form values
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s+/g, '');
    const expiryDate = document.getElementById('expiryDate').value;
    const cvv = document.getElementById('cvv').value;

    // Validate card number
    const cardNumberPattern = /^\d{16}$/;
    if (!cardNumberPattern.test(cardNumber)) {
        document.getElementById('cardNumberError').textContent = 'Invalid card number. Must be 16 digits.';
    }

    // Validate expiration date
    const expiryDatePattern = /^(0[1-9]|1[0-2])\/\d{2}$/;
    if (!expiryDatePattern.test(expiryDate)) {
        document.getElementById('expiryDateError').textContent = 'Invalid expiration date. Format MM/YY.';
    } else {
        const [month, year] = expiryDate.split('/').map(Number);
        const currentYear = new Date().getFullYear() % 100; // Last 2 digits of the current year
        const currentMonth = new Date().getMonth() + 1; // Months are 0-based in JavaScript

        if (year < currentYear || (year === currentYear && month < currentMonth)) {
            document.getElementById('expiryDateError').textContent = 'Credit card has expired.';
        }
    }

    // Validate CVV
    const cvvPattern = /^\d{3}$/;
    if (!cvvPattern.test(cvv)) {
        document.getElementById('cvvError').textContent = 'Invalid CVV. Must be 3 digits.';
    }

    // If no errors, submit the form (for demo purposes, we'll just log to the console)
    if (cardNumberPattern.test(cardNumber) &&
        expiryDatePattern.test(expiryDate) &&
        cvvPattern.test(cvv) &&
        !(year < currentYear || (year === currentYear && month < currentMonth))) {
        console.log('Form submitted successfully!');
        // Here you would normally submit the form to the server
        // e.g., this.submit(); or use fetch/axios for AJAX
    }
});
