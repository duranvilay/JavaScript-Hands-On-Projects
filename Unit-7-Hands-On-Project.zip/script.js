// script.js

// Constructor function to create movie instances
function Movie(title, director, rating) {
    this.title = title;
    this.director = director;
    this.rating = rating;
}

// Method to display movie information
Movie.prototype.displayInfo = function() {
    return `${this.title} by ${this.director}, Rating: ${this.rating}`;
};

// Closure to encapsulate private properties
function createMovie(title, director, rating) {
    let privateRating = rating; // Private property

    return {
        title: title,
        director: director,
        getRating: function() {
            return privateRating;
        },
        setRating: function(newRating) {
            if (newRating >= 1 && newRating <= 10) {
                privateRating = newRating;
            }
        },
        displayInfo: function() {
            return `${title} by ${director}, Rating: ${privateRating}`;
        }
    };
}

// Initialize an empty movie list
let movies = [];

// Function to add movie
function addMovie(event) {
    event.preventDefault();

    let title = document.getElementById('title').value;
    let director = document.getElementById('director').value;
    let rating = parseInt(document.getElementById('rating').value, 10);

    // Create a new movie instance
    let movie = createMovie(title, director, rating);

    // Add movie to the list
    movies.push(movie);

    // Update the movie list display
    updateMovieList();
}

// Function to update the movie list display
function updateMovieList() {
    let movieListUl = document.getElementById('movieListUl');
    movieListUl.innerHTML = '';

    movies.forEach(movie => {
        let li = document.createElement('li');
        li.textContent = movie.displayInfo();
        movieListUl.appendChild(li);
    });
}

// Attach event listener to the form
document.getElementById('movieForm').addEventListener('submit', addMovie);
