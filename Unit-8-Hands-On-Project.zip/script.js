document.getElementById('arrayForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const arrayInput = document.getElementById('arrayInput').value;
    const array = arrayInput.split(',').map(Number).filter(num => !isNaN(num));

    // Display the original array
    document.getElementById('originalArray').textContent = array.join(', ');

    // Sort the array
    const sortedArray = [...array].sort((a, b) => a - b);
    document.getElementById('sortedArray').textContent = sortedArray.join(', ');

    // Reverse the array
    const reversedArray = [...array].reverse();
    document.getElementById('reversedArray').textContent = reversedArray.join(', ');

    // Slice the array (for demonstration, slice the first 3 elements)
    const slicedArray = array.slice(0, 3);
    document.getElementById('slicedArray').textContent = slicedArray.join(', ');

    // Stack/Queue Operations (push and pop for stack, shift and unshift for queue)
    const stack = [...array];
    stack.push(99); // Example push
    stack.pop(); // Example pop
    document.getElementById('stackQueue').textContent = `Stack/Queue Example: ${stack.join(', ')}`;

    // Math operations
    const maxValue = Math.max(...array);
    const minValue = Math.min(...array);
    const sqrtArray = array.map(num => num >= 0 ? Math.sqrt(num).toFixed(3) : 'NaN');

    document.getElementById('maxValue').textContent = maxValue;
    document.getElementById('minValue').textContent = minValue;
    document.getElementById('sqrtArray').textContent = sqrtArray; // Display with 2 decimal places
});
